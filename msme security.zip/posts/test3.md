# Example Post 3
This is the content of the first example post.

## Subheading
More content goes here.

```python
print("hello world")
```
![image](../public/logo.png)
